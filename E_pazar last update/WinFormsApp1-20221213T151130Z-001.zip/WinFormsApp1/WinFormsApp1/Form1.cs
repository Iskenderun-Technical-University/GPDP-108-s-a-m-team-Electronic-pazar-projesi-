namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form frmShow2 = new Form();
            frmShow2.StartPosition = FormStartPosition.CenterScreen;
            frmShow2.Font = this.Font;
            frmShow2.Icon = this.Icon;
            frmShow2.Size = this.Size;
            frmShow2.Width += 150;
            frmShow2.Height += 300;
            frmShow2.Text = "Araba Reklamlar";
            frmShow2.AutoScroll = true;
            int myTop = 10;
            try
            {
                StreamReader sr = new StreamReader("Araba.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if(line!=null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Araba Markas�: " + txtWords[1] + "\t\t\t   " +
                            "Araba Modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t"+
                            "Araban�n H�s�: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;
                        
                        
                        
                        

                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Araba image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath)) pic.Image = Image.FromFile(imgPath);

                        frmShow2.Controls.Add(txt);
                        frmShow2.Controls.Add(pic);
                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                StreamReader sr = new StreamReader("Bilgisayar.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Bilgisayar Markas�: " + txtWords[1] + "\t\t\t  " +
                            "Bilgisayar modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Bilgisayar image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                StreamReader sr = new StreamReader("Motosiklet.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Motosiklet Markas�: " + txtWords[1] + "\t\t\t   " +
                            "Motosiklet modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Motosiklet image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                StreamReader sr = new StreamReader("Telefon.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Telefon Markas�: " + txtWords[1] + "\t\t\t " +
                            "Telefon modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Telefon image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form frmShow2 = new Form();
            frmShow2.StartPosition = FormStartPosition.CenterScreen;
            frmShow2.Font = this.Font;
            frmShow2.Icon = this.Icon;
            frmShow2.Size = this.Size;
            frmShow2.Width += 150;
            frmShow2.Height += 300;
            frmShow2.Text = "Emlak Reklamlar";
            frmShow2.AutoScroll = true;
            int myTop = 10;
            try
            {
                StreamReader sr = new StreamReader("Emlak.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "M�lk�n T�r�: " + txtWords[1] + "\t\t\t " +
                            "M�lk�n konumu: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Emlak image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);
                        
                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form frmShow2 = new Form();
            frmShow2.StartPosition = FormStartPosition.CenterScreen;
            frmShow2.Font = this.Font;
            frmShow2.Icon = this.Icon;
            frmShow2.Size = this.Size;
            frmShow2.Width += 150;
            frmShow2.Height += 300;
            frmShow2.Text = "Telefon Reklamlar";
            frmShow2.AutoScroll = true;
            int myTop = 10;
            try
            {
                StreamReader sr = new StreamReader("Telefon.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Telefon Markas�: " + txtWords[1] + "\t\t\t  " +
                            "Telefon modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Telefon image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form frmShow2 = new Form();
            frmShow2.StartPosition = FormStartPosition.CenterScreen;
            frmShow2.Font = this.Font;
            frmShow2.Icon = this.Icon;
            frmShow2.Size = this.Size;
            frmShow2.Width += 150;
            frmShow2.Height += 300;
            frmShow2.Text = "Bilgisayar Reklamlar";
            frmShow2.AutoScroll = true;
            int myTop = 10;
            try
            {
                StreamReader sr = new StreamReader("Bilgisayar.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Bilgisayar Markas�: " + txtWords[1] + "\t\t\t   " +
                            "Bilgisayar modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Bilgisayar image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form frmShow2 = new Form();
            frmShow2.StartPosition = FormStartPosition.CenterScreen;
            frmShow2.Font = this.Font;
            frmShow2.Icon = this.Icon;
            frmShow2.Size = this.Size;
            frmShow2.Width += 150;
            frmShow2.Height += 300;
            frmShow2.Text = "Motosiklet Reklamlar";
            frmShow2.AutoScroll = true;
            int myTop = 10;
            try
            {
                StreamReader sr = new StreamReader("Motosiklet.txt");

                string line = "";
                do
                {
                    line = sr.ReadLine();
                    if (line != null)
                    {
                        TextBox txt = new TextBox();
                        PictureBox pic = new PictureBox();
                        txt.Width = 875;
                        txt.Height = 400;
                        txt.Top = myTop;
                        string[] txtWords = line.Split(";");
                        string word = "Telefon No: " + txtWords[0] + "\t\t\t" +
                            "Motosiklet Markas�: " + txtWords[1] + "\t\t\t " +
                            "Motosiklet modeli: " + txtWords[2] + "\t\t\t" +
                            "Kullan�m Durumu: " + txtWords[3] + "\t\t\t" +
                            "�zellikler: " + txtWords[4];
                        txt.Multiline = true;
                        txt.Text = word;





                        pic.Left = 880;
                        pic.Top = myTop;
                        pic.Size = new Size(600, 400);
                        pic.SizeMode = PictureBoxSizeMode.StretchImage;
                        pic.BorderStyle = BorderStyle.FixedSingle;

                        string imgPath = "Motosiklet image/" + line.Split(";")[0] + ".jpg";
                        if (File.Exists(imgPath))
                        {
                            pic.Image = Image.FromFile(imgPath);
                            frmShow2.Controls.Add(pic);
                        }

                        frmShow2.Controls.Add(txt);

                        myTop += 400;
                    }
                } while (line != null);
                frmShow2.Show();
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}