﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt1.Text.Trim() == "" || txt2.Text.Trim() == "" || txt3.Text.Trim() == "" || txt4.Text.Trim() == "" || txt5.Text.Trim() == "")
                {
                    MessageBox.Show("Lütfen tüm bilgileri girin ve tekrar deneyin");
                    return;
                }
                StreamWriter sw = new StreamWriter("Telefon.txt", true);
                string Telefon = txt1.Text + ";"
                    + txt2.Text + ";"
                    + txt3.Text + ";"
                    + txt4.Text + ";"
                    + txt5.Text;
                sw.WriteLine(Telefon);
                sw.Close();
                if (!Directory.Exists("Telefon image"))
                {
                    Directory.CreateDirectory("Telefon image");
                }
                Resim.Image.Save("Telefon image/" + txt1.Text + ".jpg");
                MessageBox.Show("Reklam başarıyla eklendi.");

                foreach (Control c in this.Controls)
                {
                    if (c is TextBox)
                        c.Text = "";
                }
                Resim.Image = new PictureBox().Image;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ofd.ShowDialog();

                ofd.Filter = "Images |*.jpg;*.png;*.gif;*.bmp";
                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                Resim.Image = Image.FromFile(ofd.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }
    }
}
