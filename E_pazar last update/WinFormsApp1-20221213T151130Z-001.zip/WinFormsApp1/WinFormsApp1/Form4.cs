﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtSifre.Text!=txtSifreTekrar.Text)
            {
                MessageBox.Show("Şifre Tekrar Şifre ile Aynı Olmalıdır.");
                txtSifreTekrar.Text = "";
                txtSifreTekrar.Focus();
                return;
            }
            try
            {
                if (txtAd.Text.Trim() == "" || txtSoyAd.Text.Trim() == "" || txtMail.Text.Trim() == "" || txtSifre.Text.Trim() == "" || txtSifreTekrar.Text.Trim() == "")
                {
                    MessageBox.Show("Lütfen tüm bilgileri girin ve tekrar deneyin");
                    return;
                }
                StreamReader srCheck = new StreamReader("ReklamVerenler.txt");
                string strCheck = srCheck.ReadToEnd();
                srCheck.Close();
                if (strCheck.Contains(txtMail.Text + ";"))
                {
                    MessageBox.Show("Bu e-posta zaten kayıtlı, giriş yapabilirsiniz");
                    foreach (Control c in this.Controls)
                    {
                        if (c is TextBox)
                            c.Text = "";
                    }
                    return;
                }

                StreamWriter sw = new StreamWriter("ReklamVerenler.txt", true);
                string reklamVerenler = txtMail.Text + ";"
                    + txtSifre.Text + ";"
                    + txtSifreTekrar.Text + ";"
                    + txtAd.Text + ";"
                    + txtSoyAd.Text;
                sw.WriteLine(reklamVerenler);
                sw.Close();
                MessageBox.Show("Hesap başarıyla açıldı. İlan verebilirsiniz.");
                Form2 frm2 = new Form2();
                frm2.Show();
                this.Close();
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }
    }
}
