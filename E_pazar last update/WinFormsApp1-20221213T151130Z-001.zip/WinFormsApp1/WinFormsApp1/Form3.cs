﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEPosta.Text != "" && txtParola.Text != "")
                {
                    StreamReader sr = new StreamReader("ReklamVerenler.txt");
                    string line = "";
                    bool found = false;
                    do
                    {
                        line = sr.ReadLine();
                        if (line != null)
                        {
                            string[] arrData = line.Split(';');
                            if (arrData[0] == txtEPosta.Text && arrData[1] == txtParola.Text)
                            {
                                Form2 frm2 = new Form2();
                                frm2.Show();
                                this.Close();

                                found = true;
                                break;
                            }
                        }
                    } while (line != null);
                    sr.Close();
                    if (!found)
                    {
                        MessageBox.Show("Girdiğiniz bilgiler yanlış lütfen tekrar deneyiniz");
                        txtEPosta.Focus();
                        txtEPosta.SelectAll();
                        txtParola.Text = "";
                    }

                }
                else
                {
                    MessageBox.Show("Lütfen e-postanızı ve şifrenizi giriniz.");
                    txtParola.Focus();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }
    }
}
