﻿namespace WinFormsApp1
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.Resim = new System.Windows.Forms.PictureBox();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.Resim)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(745, 650);
            this.button2.Margin = new System.Windows.Forms.Padding(5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(520, 116);
            this.button2.TabIndex = 27;
            this.button2.Text = "Ana sayfaya dön";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(963, 479);
            this.button3.Margin = new System.Windows.Forms.Padding(5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(340, 108);
            this.button3.TabIndex = 26;
            this.button3.Text = "Resim ekle";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 530);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(205, 57);
            this.label5.TabIndex = 21;
            this.label5.Text = "Özellikler:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 410);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(357, 57);
            this.label4.TabIndex = 22;
            this.label4.Text = "Kullanım Durumu:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 300);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(362, 57);
            this.label3.TabIndex = 23;
            this.label3.Text = "Bilgisayar  Modeli:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 193);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(364, 57);
            this.label2.TabIndex = 24;
            this.label2.Text = "Bilgisayar Markası:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 75);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 57);
            this.label1.TabIndex = 25;
            this.label1.Text = "Telefon No:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(129, 650);
            this.button1.Margin = new System.Windows.Forms.Padding(5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(520, 116);
            this.button1.TabIndex = 20;
            this.button1.Text = "Reklam Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(422, 521);
            this.txt5.Margin = new System.Windows.Forms.Padding(5);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(455, 63);
            this.txt5.TabIndex = 15;
            // 
            // txt4
            // 
            this.txt4.Location = new System.Drawing.Point(422, 401);
            this.txt4.Margin = new System.Windows.Forms.Padding(5);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(455, 63);
            this.txt4.TabIndex = 16;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(422, 291);
            this.txt3.Margin = new System.Windows.Forms.Padding(5);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(455, 63);
            this.txt3.TabIndex = 17;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(422, 183);
            this.txt2.Margin = new System.Windows.Forms.Padding(5);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(455, 63);
            this.txt2.TabIndex = 18;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(422, 75);
            this.txt1.Margin = new System.Windows.Forms.Padding(5);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(455, 63);
            this.txt1.TabIndex = 0;
            // 
            // Resim
            // 
            this.Resim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Resim.Location = new System.Drawing.Point(963, 75);
            this.Resim.Margin = new System.Windows.Forms.Padding(5);
            this.Resim.Name = "Resim";
            this.Resim.Size = new System.Drawing.Size(339, 332);
            this.Resim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Resim.TabIndex = 14;
            this.Resim.TabStop = false;
            // 
            // ofd
            // 
            this.ofd.FileName = "Bilgisayar Resimi ekleyiniz.";
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(23F, 57F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1329, 995);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.Resim);
            this.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(9);
            this.Name = "Form9";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form9";
            ((System.ComponentModel.ISupportInitialize)(this.Resim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button2;
        private Button button3;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button1;
        private TextBox txt5;
        private TextBox txt4;
        private TextBox txt3;
        private TextBox txt2;
        private TextBox txt1;
        private PictureBox Resim;
        private OpenFileDialog ofd;
    }
}